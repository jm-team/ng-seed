/**
 * Created by Administrator on 2016/7/4 0004.
 */
require('app');
require('page');
require('service');
require('./directive/directive.js');
require('../css/style.css');
