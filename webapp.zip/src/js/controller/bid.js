/**
 * Created by Administrator on 2016/7/4 0004.
 */
import app from "app";

app.registerController('BidCtrl', ['$scope', ($scope) => {
  $scope.title = "Bid Page";
}]);
